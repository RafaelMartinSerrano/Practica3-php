<?php  
include 'conexionbd.php';
session_start();
//isset — Determina si una variable está definida y no es null
if (isset($_SESSION['masControl']))
{
	if($_SESSION['sesionJuego']==true)
	{
		echo "<script>
				var peticion=confirm('Sesion correcta ¿continuas?');
				console.log(peticion);
				if(peticion){
					console.log(peticion);
				}     			
			</script>";
	}
	$con=conexion();
	$sql="UPDATE USUARIOS SET GANADAS=" . $_SESSION['victorias'] .", PERDIDAS=" . $_SESSION['perdidas'] . " WHERE EMAIL='" . $_SESSION['email'] . "';";
	$resultado=mysqli_query($con, $sql);
	mysqli_close($con);
}
else
{
	session_destroy();
	header("location:./index.php");
}


?>



<html>
	<head>
		<meta charset="UTF-8"/>
		<meta name="viewport" content="width=device-width, initial-scale=1.0"/>
		<link href="https://fonts.googleapis.com/css?family=Bebas+Neue&display=swap" rel="stylesheet">
		<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
        <title>Inicio</title>
	</head>
	<body>
		<div class="caja_usuario">
			<div class="datos_usuario">
				<h1><?php echo ' ' .$_SESSION['nombre'] . ' ' . $_SESSION['apellido'];?></h1> 
			</div>


<div>
<p>Adivina el numero [1-100]:</p>
<form name="form1" method="post" action="">
	<?php 
	/* Accion del boton */ 
	if (isset($_POST["button"])) {
		$numero1=$_POST["num1"];
	
		/*  */
		if ($_SESSION['numeroaleatorio']<$numero1){
			if($_SESSION['nummax'] > $numero1){
				$_SESSION['nummax'] = $numero1;
			}
		}else{
			if($_SESSION['nummin'] < $numero1){
				$_SESSION['nummin'] = $numero1;
			}
		}

		if ($_SESSION['numeroaleatorio']==$numero1) {
			echo "FELICIDADES HAS ADIVINADO EL NUMERO!!,ERA   ".$_SESSION['numeroaleatorio'];
			$_SESSION['victorias'] = $_SESSION['victorias'] + 1;

			//Update del record
			$con=conexion();
			$sql = "update USUARIOS set RECORD = " . $_SESSION['TRECO'] . " where email = '" . $email ."';";
			mysqli_query($con, $sql);
			mysqli_close($con);

			//Update de las victorias
			$con=conexion();
			$sql = "update USUARIOS set GANADAS = " . $_SESSION['victorias'] . " where email = '" . $email ."';";
			mysqli_query($con, $sql);
			mysqli_close($con);

			//Reiniciar partida
			$_SESSION['numeroaleatorio']=mt_rand(1, 100);
			$_SESSION['nummax']=100;
			$_SESSION['nummin']=1;
			$_SESSION['TRECO']=0;

		}
		else{
			$vNumMin = $_SESSION['nummin'];
			$vNumMax = $_SESSION['nummax'];
			echo "Fallaste, el numero esta entre : $vNumMin y $vNumMax";
			$_SESSION['TRECO'] = $_SESSION['TRECO'] + 1;
			if($contadorIntentos  == 10){
				echo 'Perdiste';
				$_SESSION['perdidas'] = $_SESSION['perdidas'] + 1;
				$_SESSION['numeroaleatorio']=mt_rand(1, 100);
				$_SESSION['nummax']=100;
				$_SESSION['nummin']=1;
				$_SESSION['TRECO']=0;

				//Update de las perdidas
				$con=conexion();
				$sql = "update USUARIOS set PERDIDAS = " . $_SESSION['perdidas']  . " where email='" . $email ."';";
				mysqli_query($con, $sql);
				mysqli_close($con);

			}
		}
	}

	?>

  <p>
  
    <label for="num1"></label>
    <input type="text" name="num1" id="num1">
  </p>
  <p>
    <input type="submit" name="button" id="button" value="Adivinar" onClick="compuaprende">
  </p>
</form>
</div>
			<div class="puntuacion_usuario">
                    
				<p class="victorias"> Victorias: <?php echo $_SESSION['victorias'];?> </p>
				<br/>
				<p class="derrotas">Derrotas: <?php echo $_SESSION['perdidas'];?> </p>
			</div>
		</div>					
	</body>
</html> 
