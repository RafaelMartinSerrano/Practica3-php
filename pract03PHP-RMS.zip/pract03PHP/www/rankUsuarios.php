<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8"/>
        <title>Ranking</title>
        <link rel="stylesheet" href="./css/lista2.css">
    </head>
    <body>
        <div>
            <button> <a href="index.php">Atras</a></button>
        </div>
        <center>
            <table>
                <thead>
                    <tr>
                        <th>Nombre</th>
                        <th>Apellido</th>
                        <th>Email</th>
                        <th>Victorias</th>
                        <th>Derrotas</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                        include 'conexionbd.php';
                        $con=conexion();
                        $sql="select email, nombre, fecha_nacimiento, apellido, IFNULL(ganadas,0), IFNULL(perdidas,0) from USUARIOS order by IFNULL(ganadas,0) DESC;";
                        $result=mysqli_query($con, $sql);
                        if (mysqli_num_rows($result) > 0){
                            while ($row = mysqli_fetch_assoc($result)) {
                                echo "<tr>";
                                echo "<td>" . $row['nombre'] . "</td>";
                                echo "<td>" . $row['apellido'] . "</td>";
                                echo "<td>" . $row['email'] . "</td>";
                                echo "<td>" . $row['IFNULL(ganadas,0)'] . "</td>";
                                echo "<td>" . $row['IFNULL(perdidas,0)'] . "</td>";
                                echo "</tr>";
                            }
                        } else {
                            echo "<tr><td colspan='5'>0 resultados</td></tr>";
                        }
                        mysqli_close($con);
                    ?>
                </tbody>
            </table>
        </center>
    </body>
</html>

